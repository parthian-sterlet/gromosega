import struct

MAX_MOTIF_LENGTH_NT = 31
_EXCEL_PIXELS_PER_UNIT = 7.0
_EXCEL_PADDING_PX = 5.0


def png_dimensions(png_bytes: bytes) -> tuple[int, int]:
    if len(png_bytes) < 24:
        raise ValueError("Invalid PNG: file too small")
    if png_bytes[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError("Invalid PNG signature")
    width = int(struct.unpack(">I", png_bytes[16:20])[0])
    height = int(struct.unpack(">I", png_bytes[20:24])[0])
    if width <= 0 or height <= 0:
        raise ValueError("Invalid PNG dimensions")
    return width, height


def display_width_for_fixed_height(
    png_width_px: int,
    png_height_px: int,
    display_height_units: float,
) -> float:
    return display_height_units * (png_width_px / png_height_px)


def capped_motif_length(
    motif_length_nt: int,
    max_motif_length_nt: int = MAX_MOTIF_LENGTH_NT,
) -> int:
    return max(0, min(motif_length_nt, max_motif_length_nt))


def logo_column_width(
    motif_length_nt: int,
    base_width_per_nt: float,
    logo_dpi: int,
    min_col_width: float = 15.0,
    max_col_width: float = 60.0,
) -> tuple[float, int]:
    clamped_nt = capped_motif_length(motif_length_nt)
    logo_width_px = clamped_nt * base_width_per_nt * logo_dpi
    col_width = (logo_width_px + _EXCEL_PADDING_PX) / _EXCEL_PIXELS_PER_UNIT
    col_width = max(min_col_width, min(max_col_width, col_width))
    col_width_px = int(col_width * _EXCEL_PIXELS_PER_UNIT + _EXCEL_PADDING_PX)
    return col_width, col_width_px


def heatmap_row_height_in(
    logo_height_in: float,
) -> float:
    return max(0.12, logo_height_in)


def heatmap_cell_width_in(row_height_in: float) -> float:
    return max(0.14, row_height_in * 1.3)


def heatmap_logo_area_width_in(
    motif_length_nt: int,
    base_width_per_nt: float,
    logo_dpi: int = 300,
) -> float:
    _, logo_col_width_px = logo_column_width(
        motif_length_nt=motif_length_nt,
        base_width_per_nt=base_width_per_nt,
        logo_dpi=logo_dpi,
    )
    return (logo_col_width_px / 96.0) + 0.2
