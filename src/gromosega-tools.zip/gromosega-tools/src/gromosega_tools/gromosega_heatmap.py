#!/usr/bin/env python3
# /// script
# requires-python = ">=3.11"
# dependencies = [
#   "logomaker",
#   "matplotlib",
#   "numpy>=2.0",
#   "pandas",
#   "seaborn",
#   "pyjaspar>=4.0",
# ]
# ///

import argparse
import io
import sys

import logomaker
import matplotlib

matplotlib.use("Agg")
import matplotlib.colors as mcolors
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from matplotlib.colors import BoundaryNorm
from matplotlib.gridspec import GridSpec

from gromosega_tools.logo_geometry import (
    display_width_for_fixed_height,
    heatmap_cell_width_in,
    heatmap_logo_area_width_in,
    heatmap_row_height_in,
    png_dimensions,
)
from gromosega_tools.logo_service import collect_logo_pngs
from gromosega_tools.logo_workers import (
    LogoRenderParams,
    fetch_motif_with_fallback,
    load_resolver_sources,
)
from gromosega_tools.resource_paths import default_hocomoco_path


def generate_heatmap(
    input_path: str,
    output_path: str,
    db_mode: str,
    hocomoco_path: str | None = None,
    max_rank: int | None = None,
    jobs: int = 1,
    cache_dir: str | None = None,
    no_cache: bool = False,
    logo_height: float = 1.5,
    base_width_per_nt: float = 0.1,
    logo_dpi: int = 300,
    extra_motifs_path: str | None = None,
    display_mode: str = "rank",
):
    """
    Main plotting logic.
    """
    df = pd.read_csv(input_path, sep="\t", skiprows=1)
    df = df.rename(
        columns={"Unnamed: 0": "Family", "Unnamed: 1": "TF", "Unnamed: 2": "Motif"}
    )

    info = df.iloc[:, :3]
    heatmap_data = df.iloc[:, 3:].apply(pd.to_numeric, errors="coerce")
    motif_ids = [str(m).strip() for m in info["Motif"]]
    is_png_output = output_path.lower().endswith(".png")

    step = int(heatmap_data.columns[1]) - int(heatmap_data.columns[0])
    mid = step / 2

    n_motifs = len(info)
    n_cols_heatmap = heatmap_data.shape[1]
    y_labels = [
        f"{row.Family} | {row.TF} | {str(row.Motif).strip()}"
        for row in info.itertuples()
    ]

    motif_matrices = None
    logo_images = None
    max_motif_nt = 1
    max_logo_display_width = 1.0
    render_dpi = max(1, logo_dpi)
    logo_height_px = max(1, int(round(logo_height * render_dpi)))

    if is_png_output:
        render_params = LogoRenderParams(
            logo_height_px=logo_height_px,
            logo_dpi=render_dpi,
            base_width_per_nt=base_width_per_nt,
            font_name="sans-serif",
        )
        logo_map, render_errors = collect_logo_pngs(
            motif_ids=motif_ids,
            db_mode=db_mode,
            hocomoco_path=hocomoco_path,
            extra_motifs_path=extra_motifs_path,
            render_params=render_params,
            jobs=jobs,
            cache_dir=cache_dir,
            no_cache=no_cache,
        )
        logo_images = []
        for motif_id in motif_ids:
            item = logo_map.get(motif_id)
            if item is None:
                logo_images.append(None)
                continue
            png_bytes, motif_nt = item
            image = plt.imread(io.BytesIO(png_bytes), format="png")
            png_width_px, png_height_px = png_dimensions(png_bytes)
            display_width = display_width_for_fixed_height(
                png_width_px,
                png_height_px,
                display_height_units=2.0,
            )
            logo_images.append((image, display_width))
            max_motif_nt = max(max_motif_nt, motif_nt)
            max_logo_display_width = max(max_logo_display_width, display_width)

        for motif_id, error_text in render_errors.items():
            print(
                f"Warning: Could not render motif logo {motif_id}: {error_text}",
                file=sys.stderr,
            )
    else:
        (
            primary_db,
            primary_mode,
            secondary_db,
            secondary_mode,
            extra_motifs,
        ) = load_resolver_sources(
            db_mode=db_mode,
            hocomoco_path=hocomoco_path,
            jaspar_release="JASPAR2026",
            extra_motifs_path=extra_motifs_path,
        )
        motif_matrices = []
        for motif_name in motif_ids:
            m = fetch_motif_with_fallback(
                motif_name,
                primary_db,
                primary_mode=primary_mode,
                secondary_db=secondary_db,
                secondary_mode=secondary_mode,
                extra_motifs=extra_motifs,
            )
            motif_matrices.append(m)
        max_motif_nt = max((len(m) for m in motif_matrices), default=0)
        for motif_len in (len(m) for m in motif_matrices):
            motif_width_in = motif_len * base_width_per_nt
            display_width = 2.0 * (motif_width_in / max(0.01, logo_height))
            max_logo_display_width = max(max_logo_display_width, display_width)

    plt.rcParams["font.family"] = "monospace"
    colors = [(0.0, "#FF0000"), (0.5, "#32AD2D"), (1.0, "#0004FF")]
    custom_cmap = mcolors.LinearSegmentedColormap.from_list("blue_green_red", colors)

    finite_values = heatmap_data.to_numpy(dtype=float)
    finite_values = finite_values[np.isfinite(finite_values)]
    if finite_values.size == 0:
        raise ValueError("Input table contains no numeric values")

    if display_mode == "rank":
        if max_rank is None:
            max_rank = int(finite_values.max())
        bounds = np.arange(1 - mid, max_rank + mid + step, step)
        n_bins = len(bounds) - 1
        norm = BoundaryNorm(bounds, n_bins)
        cmap = custom_cmap.resampled(n_bins)
        ticks = np.arange(1, max_rank + step, step)
        colorbar_label = "Rank"
    else:
        norm = mcolors.Normalize(vmin=0.0, vmax=1.0)
        base_cmap = plt.get_cmap("afmhot_r")
        cmap = mcolors.LinearSegmentedColormap.from_list(
            "afmhot_r_part",
            base_cmap(np.linspace(0.0, 0.9, 256))
            )
        ticks = np.round(np.arange(0.0, 1.0 + 0.1, 0.1), 1)
        colorbar_label = "Ratio"

    row_height = heatmap_row_height_in(logo_height_in=logo_height)
    heatmap_cell_width = heatmap_cell_width_in(row_height_in=row_height)
    logos_area_width = heatmap_logo_area_width_in(
        motif_length_nt=max_motif_nt,
        base_width_per_nt=base_width_per_nt,
        logo_dpi=render_dpi,
    )
    proportional_logo_width = row_height * (max_logo_display_width / 2.0)
    logos_area_width = max(logos_area_width, proportional_logo_width + 0.1)

    total_width = logos_area_width + (n_cols_heatmap * heatmap_cell_width)
    cbar_height = max(0.18, row_height * 0.7)
    total_height = (n_motifs * row_height) + cbar_height
    heatmap_width = n_cols_heatmap * heatmap_cell_width
    max_cbar_ticks = max(3, int(heatmap_width / 0.28))
    if len(ticks) > max_cbar_ticks:
        tick_idx = np.linspace(0, len(ticks) - 1, max_cbar_ticks, dtype=int)
        cbar_ticks = [float(v) for v in ticks[tick_idx]]
    else:
        cbar_ticks = [float(v) for v in ticks]

    fig = plt.figure(figsize=(total_width, total_height), dpi=render_dpi)

    gs = GridSpec(
        n_motifs + 1,
        2,
        width_ratios=[logos_area_width, n_cols_heatmap * heatmap_cell_width],
        height_ratios=[cbar_height] + [row_height] * n_motifs,
        hspace=0.5,
        wspace=0.05,
    )

    for i in range(n_motifs):
        logo_item = None
        motif_matrix = None
        if is_png_output:
            logo_item = logo_images[i] if logo_images is not None else None
        else:
            motif_matrix = motif_matrices[i] if motif_matrices is not None else None

        ax_logo = fig.add_subplot(gs[i + 1, 0])
        if is_png_output:
            if logo_item is not None:
                image, motif_display_width = logo_item
                ax_logo.imshow(
                    image,
                    aspect="auto",
                    interpolation="nearest",
                    extent=(-0.5, motif_display_width - 0.5, 0.0, 2.0),
                )
        else:
            logomaker.Logo(
                motif_matrix,
                ax=ax_logo,
                shade_below=0.0,
                fade_below=0.0,
                vsep=0.0,
                font_name="sans-serif",
            )

        ax_logo.set_xlim((-0.5, max_logo_display_width - 0.5))
        ax_logo.set_ylim((0.0, 2.0))
        ax_logo.set_xticks([])
        ax_logo.set_yticks([])

        ax_logo.set_ylabel(
            y_labels[i],
            rotation=0,
            ha="right",
            va="center",
            fontsize=8,
            labelpad=10,
        )

        for spine in ax_logo.spines.values():
            spine.set_visible(False)

    # Draw Heatmap
    ax_heatmap = fig.add_subplot(gs[1:, 1])
    heatmap = sns.heatmap(
        heatmap_data,
        xticklabels=True,
        yticklabels=False,
        cmap=cmap,
        norm=norm,
        ax=ax_heatmap,
        square=False,
        cbar=False,
    )

    ax_heatmap.set_ylabel("")
    ax_heatmap.set_yticks([])
    ax_heatmap.set_xlabel("Group size", fontsize=8, labelpad=8)

    all_tick_positions = ax_heatmap.get_xticks()
    all_tick_labels = [tick.get_text() for tick in ax_heatmap.get_xticklabels()]
    min_xtick_gap_in = 0.22
    x_tick_step = max(1, int(np.ceil(min_xtick_gap_in / max(1e-6, heatmap_cell_width))))
    shown_positions = all_tick_positions[::x_tick_step]
    shown_labels = all_tick_labels[::x_tick_step]
    ax_heatmap.set_xticks([float(v) for v in shown_positions])
    ax_heatmap.set_xticklabels(
        shown_labels,
        rotation=0,
        ha="center",
        fontsize=7 if x_tick_step == 1 else 6,
    )

    cbar = fig.colorbar(
        heatmap.collections[0],
        cax=fig.add_subplot(gs[0, 1]),
        orientation="horizontal",
    )
    cbar.set_label(colorbar_label, fontsize=8, labelpad=4)
    cbar.set_ticks(cbar_ticks)
    _ = cbar.ax.minorticks_off()
    cbar.ax.tick_params(labelsize=7, pad=1)
    cbar.ax.xaxis.set_ticks_position("top")
    cbar.ax.xaxis.set_label_position("top")
    cbar.outline.set_visible(False)
    for spine in cbar.ax.spines.values():
        spine.set_visible(False)

    max_label_len = max((len(label) for label in y_labels), default=20)
    left_margin = min(0.65, max(0.28, 0.18 + 0.006 * max_label_len))
    bottom_margin = 0.1 if x_tick_step == 1 else 0.08
    plt.subplots_adjust(left=left_margin, right=0.92, top=0.93, bottom=bottom_margin)
    fig.savefig(output_path, dpi=render_dpi, bbox_inches="tight", pad_inches=0.05)
    print(f"Success: Heatmap saved to {output_path}")


def add_heatmap_subparser(subparsers: argparse._SubParsersAction):
    default_hocomoco = default_hocomoco_path()
    parser = subparsers.add_parser("heatmap", help="Build motif heatmap image")
    parser.add_argument("-i", "--input", required=True, help="Path to input TSV table")
    parser.add_argument(
        "-o",
        "--output",
        required=True,
        help="Path to save the output image (e.g. out.png, out.pdf)",
    )
    parser.add_argument(
        "--db",
        choices=["jaspar", "hocomoco"],
        required=True,
        help="Motif database to use",
    )
    mode_group = parser.add_mutually_exclusive_group(required=True)
    mode_group.add_argument(
        "--rank",
        dest="display_mode",
        action="store_const",
        const="rank",
        help="Render values with the rank color scale",
    )
    mode_group.add_argument(
        "--ratio",
        dest="display_mode",
        action="store_const",
        const="ratio",
        help="Render values with a grayscale ratio scale",
    )
    parser.add_argument(
        "--hocomoco-path",
        default=default_hocomoco,
        help=f"Path to HOCOMOCO data (default: {default_hocomoco})",
    )
    parser.add_argument(
        "--max-rank",
        type=int,
        help="Maximum rank for --rank color scaling (calculated if not provided)",
    )
    parser.add_argument(
        "-j",
        "--jobs",
        type=int,
        default=1,
        help="Number of worker processes for uncached PNG logo rendering (default: %(default)s)",
    )
    parser.add_argument("--cache-dir", help="Path to PNG logo cache directory")
    parser.add_argument(
        "--no-cache",
        action="store_true",
        help="Disable PNG logo cache",
    )
    parser.add_argument(
        "--logo-height",
        type=float,
        default=0.3,
        help="Base logo height in inches (default: %(default)s)",
    )
    parser.add_argument(
        "--base-width-per-nt",
        type=float,
        default=0.15,
        help="Base width per nucleotide for cached logo rendering (default: %(default)s)",
    )
    parser.add_argument(
        "--logo-dpi",
        type=int,
        default=300,
        help="DPI used for logo rendering (default: %(default)s)",
    )
    parser.add_argument(
        "--extra-motifs-path",
        help="Path to fallback motifs file in FASTA-like PFM format",
    )
    parser.set_defaults(handler=run_heatmap_command)


def run_heatmap_command(args: argparse.Namespace):
    if args.db == "hocomoco" and not args.hocomoco_path:
        raise ValueError("--hocomoco-path is required when --db is hocomoco")
    if args.display_mode == "ratio" and args.max_rank is not None:
        raise ValueError("--max-rank can only be used with --rank")

    generate_heatmap(
        input_path=args.input,
        output_path=args.output,
        db_mode=args.db,
        hocomoco_path=args.hocomoco_path,
        max_rank=args.max_rank,
        jobs=max(1, args.jobs),
        cache_dir=args.cache_dir,
        no_cache=args.no_cache,
        logo_height=args.logo_height,
        base_width_per_nt=args.base_width_per_nt,
        logo_dpi=args.logo_dpi,
        extra_motifs_path=args.extra_motifs_path,
        display_mode=args.display_mode,
    )
