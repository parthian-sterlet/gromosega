import argparse
import sys

from gromosega_tools.gromosega_heatmap import add_heatmap_subparser
from gromosega_tools.gromosega_xlsx import add_xlsx_subparser


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="gromosega-tools",
        description="Utilities for Gromosega motif visualization",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)
    add_heatmap_subparser(subparsers)
    add_xlsx_subparser(subparsers)
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    try:
        args.handler(args)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
