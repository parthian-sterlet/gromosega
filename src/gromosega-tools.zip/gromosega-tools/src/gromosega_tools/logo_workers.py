import io
from concurrent.futures import ProcessPoolExecutor
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import cast

import logomaker
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from pyjaspar import jaspardb


@dataclass(frozen=True)
class LogoRenderParams:
    logo_height_px: int = 40
    logo_dpi: int = 300
    base_width_per_nt: float = 0.06
    font_name: str = "sans-serif"
    transparent: bool = True
    pad_inches: float = 0.0

    def to_key_dict(self) -> dict[str, object]:
        return asdict(self)


def fetch_motif(tag: str, data_base, mode: str = "jaspar") -> pd.DataFrame:
    if mode == "jaspar":
        motif = data_base.fetch_motif_by_id(tag)
        if motif is None:
            raise ValueError(f"Motif {tag} not found.")
        motif_matrix = pd.DataFrame(motif.pwm)
        motif_matrix.columns = ["A", "C", "G", "T"]
        return logomaker.transform_matrix(
            motif_matrix, from_type="probability", to_type="information"
        )

    if mode == "hocomoco":
        motif_matrix = pd.DataFrame(data_base.loc[tag]["pfm"])
        motif_matrix.columns = ["A", "C", "G", "T"]
        return logomaker.transform_matrix(
            motif_matrix, from_type="probability", to_type="information"
        )

    raise ValueError(f"Unknown mode: {mode}")


def load_extra_motifs(extra_motifs_path: str | None) -> dict[str, pd.DataFrame]:
    if not extra_motifs_path:
        return {}

    path = Path(extra_motifs_path).expanduser().resolve()
    records: dict[str, pd.DataFrame] = {}
    current_name: str | None = None
    rows: list[list[float]] = []

    def flush_current() -> None:
        nonlocal current_name
        nonlocal rows
        if current_name is None or not rows:
            current_name = None
            rows = []
            return
        matrix = pd.DataFrame(rows, columns=["A", "C", "G", "T"])
        records[current_name] = logomaker.transform_matrix(
            matrix, from_type="probability", to_type="information"
        )
        current_name = None
        rows = []

    with path.open("r", encoding="utf-8") as handle:
        for raw_line in handle:
            line = raw_line.strip()
            if not line:
                continue
            if line.startswith(">"):
                flush_current()
                current_name = line[1:].strip()
                continue

            values = line.split()
            if len(values) != 4:
                raise ValueError(
                    f"Invalid extra motif row '{line}' in {path}; expected 4 columns"
                )
            rows.append([float(v) for v in values])

    flush_current()
    return records


def render_logo_png_bytes(
    motif_matrix: pd.DataFrame, params: LogoRenderParams
) -> bytes:
    motif_len = len(motif_matrix)
    fig_width = max(0.2, motif_len * params.base_width_per_nt)
    fig_height = max(0.2, params.logo_height_px / params.logo_dpi)
    fig, ax = plt.subplots(figsize=(fig_width, fig_height), dpi=params.logo_dpi)

    try:
        ax.set_position((0.0, 0.0, 1.0, 1.0))
        ax.set_axis_off()
        logomaker.Logo(motif_matrix, ax=ax, font_name=params.font_name)
        ax.set_xlim(-0.5, motif_len - 0.5)
        ax.set_ylim(0.0, 2.0)
        fig.subplots_adjust(left=0.0, right=1.0, bottom=0.0, top=1.0)

        buffer = io.BytesIO()
        fig.savefig(
            buffer,
            format="png",
            transparent=params.transparent,
            pad_inches=params.pad_inches,
        )
        buffer.seek(0)
        return buffer.read()
    finally:
        plt.close(fig)


def load_db(db_mode: str, hocomoco_path: str | None, jaspar_release: str):
    if db_mode == "jaspar":
        return jaspardb(release=jaspar_release)
    if db_mode == "hocomoco":
        if hocomoco_path is None:
            raise ValueError("hocomoco_path is required for hocomoco database mode")
        return pd.read_json(hocomoco_path, lines=True, compression="zip").set_index(
            "name"
        )
    raise ValueError(f"Unknown mode: {db_mode}")


def _other_mode(db_mode: str) -> str:
    if db_mode == "jaspar":
        return "hocomoco"
    if db_mode == "hocomoco":
        return "jaspar"
    raise ValueError(f"Unknown mode: {db_mode}")


def load_resolver_sources(
    db_mode: str,
    hocomoco_path: str | None,
    jaspar_release: str,
    extra_motifs_path: str | None,
) -> tuple[object, str, object | None, str | None, dict[str, pd.DataFrame]]:
    primary_mode = db_mode
    primary_db = load_db(primary_mode, hocomoco_path, jaspar_release)
    secondary_mode = _other_mode(db_mode)

    secondary_db = None
    try:
        secondary_db = load_db(secondary_mode, hocomoco_path, jaspar_release)
    except Exception:
        secondary_db = None

    extra_motifs = load_extra_motifs(extra_motifs_path)
    return primary_db, primary_mode, secondary_db, secondary_mode, extra_motifs


def fetch_motif_with_fallback(
    tag: str,
    primary_db,
    primary_mode: str,
    secondary_db=None,
    secondary_mode: str | None = None,
    extra_motifs: dict[str, pd.DataFrame] | None = None,
) -> pd.DataFrame:
    errors: list[str] = []

    try:
        return fetch_motif(tag, primary_db, mode=primary_mode)
    except Exception as exc:
        errors.append(f"{primary_mode}: {exc}")

    if secondary_db is not None and secondary_mode is not None:
        try:
            return fetch_motif(tag, secondary_db, mode=secondary_mode)
        except Exception as exc:
            errors.append(f"{secondary_mode}: {exc}")

    if extra_motifs is not None and tag in extra_motifs:
        return extra_motifs[tag]

    details = "; ".join(errors) if errors else "not found"
    raise ValueError(f"Motif {tag} not found in fallback chain ({details})")


_WORKER_DB = None
_WORKER_DB_MODE = None
_WORKER_SECONDARY_DB = None
_WORKER_SECONDARY_DB_MODE = None
_WORKER_EXTRA_MOTIFS: dict[str, pd.DataFrame] | None = None


def _init_worker(
    db_mode: str,
    hocomoco_path: str | None,
    jaspar_release: str,
    extra_motifs_path: str | None,
):
    global _WORKER_DB
    global _WORKER_DB_MODE
    global _WORKER_SECONDARY_DB
    global _WORKER_SECONDARY_DB_MODE
    global _WORKER_EXTRA_MOTIFS

    (
        _WORKER_DB,
        _WORKER_DB_MODE,
        _WORKER_SECONDARY_DB,
        _WORKER_SECONDARY_DB_MODE,
        _WORKER_EXTRA_MOTIFS,
    ) = load_resolver_sources(
        db_mode=db_mode,
        hocomoco_path=hocomoco_path,
        jaspar_release=jaspar_release,
        extra_motifs_path=extra_motifs_path,
    )


def _render_single_worker(task: tuple[str, LogoRenderParams]) -> tuple[str, bytes, int]:
    motif_id, params = task
    if _WORKER_DB_MODE is None:
        raise RuntimeError("Worker is not initialized")
    matrix = fetch_motif_with_fallback(
        motif_id,
        _WORKER_DB,
        primary_mode=cast(str, _WORKER_DB_MODE),
        secondary_db=_WORKER_SECONDARY_DB,
        secondary_mode=cast(str | None, _WORKER_SECONDARY_DB_MODE),
        extra_motifs=_WORKER_EXTRA_MOTIFS,
    )
    return motif_id, render_logo_png_bytes(matrix, params), len(matrix)


def render_missing_logos(
    motif_ids: list[str],
    db_mode: str,
    hocomoco_path: str | None,
    extra_motifs_path: str | None,
    jaspar_release: str,
    render_params: LogoRenderParams,
    jobs: int,
    strict: bool,
) -> tuple[dict[str, tuple[bytes, int]], dict[str, str]]:
    results: dict[str, tuple[bytes, int]] = {}
    errors: dict[str, str] = {}
    unique_motifs = list(dict.fromkeys(motif_ids))

    if not unique_motifs:
        return results, errors

    if jobs <= 1:
        (
            primary_db,
            primary_mode,
            secondary_db,
            secondary_mode,
            extra_motifs,
        ) = load_resolver_sources(
            db_mode=db_mode,
            hocomoco_path=hocomoco_path,
            jaspar_release=jaspar_release,
            extra_motifs_path=extra_motifs_path,
        )
        for motif_id in unique_motifs:
            try:
                matrix = fetch_motif_with_fallback(
                    motif_id,
                    primary_db,
                    primary_mode=primary_mode,
                    secondary_db=secondary_db,
                    secondary_mode=secondary_mode,
                    extra_motifs=extra_motifs,
                )
                results[motif_id] = (
                    render_logo_png_bytes(matrix, render_params),
                    len(matrix),
                )
            except Exception as exc:
                if strict:
                    raise
                errors[motif_id] = str(exc)
        return results, errors

    with ProcessPoolExecutor(
        max_workers=jobs,
        initializer=_init_worker,
        initargs=(db_mode, hocomoco_path, jaspar_release, extra_motifs_path),
    ) as executor:
        futures = {
            executor.submit(_render_single_worker, (motif_id, render_params)): motif_id
            for motif_id in unique_motifs
        }
        for future, motif_id in futures.items():
            try:
                _, png_bytes, motif_len = future.result()
                results[motif_id] = (png_bytes, motif_len)
            except Exception as exc:
                if strict:
                    raise
                errors[motif_id] = str(exc)

    return results, errors
