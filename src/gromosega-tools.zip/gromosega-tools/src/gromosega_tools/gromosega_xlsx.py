#!/usr/bin/env python3
# /// script
# requires-python = ">=3.11"
# dependencies = [
#   "logomaker",
#   "matplotlib",
#   "numpy>=2.0",
#   "pandas",
#   "pyjaspar>=4.0",
#   "xlsxwriter",
# ]
# ///

import argparse
import io
import sys

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors

from gromosega_tools.logo_geometry import logo_column_width, png_dimensions
from gromosega_tools.logo_service import collect_logo_pngs
from gromosega_tools.logo_workers import LogoRenderParams
from gromosega_tools.resource_paths import default_hocomoco_path


def generate_excel_with_logos(
    input_path: str,
    output_path: str,
    db_mode: str,
    hocomoco_path: str | None = None,
    max_rank: int | None = None,
    base_width_per_nt: float = 0.1,
    logo_height: float = 1.5,
    hide_values: bool = False,
    jobs: int = 1,
    cache_dir: str | None = None,
    no_cache: bool = False,
    logo_dpi: int = 300,
    extra_motifs_path: str | None = None,
    display_mode: str = "rank",
):
    # Загрузка данных
    df = pd.read_csv(input_path, sep="\t", skiprows=1)
    df = df.rename(
        columns={"Unnamed: 0": "Family", "Unnamed: 1": "TF", "Unnamed: 2": "Motif"}
    )
    df.insert(3, "Logo", "")

    # Создаем книгу и лист
    writer = pd.ExcelWriter(output_path, engine="xlsxwriter")
    workbook = writer.book
    worksheet = workbook.add_worksheet("Motifs")

    # --- Стилизация ---
    header_format = workbook.add_format(
        {
            "bold": True,
            "bg_color": "#D7E4BC",
            "border": 1,
            "align": "center",
            "valign": "vcenter",
        }
    )
    cell_format = workbook.add_format(
        {"border": 1, "align": "center", "valign": "vcenter"}
    )
    heatmap_text_format = workbook.add_format(
        {
            "border": 1,
            "align": "center",
            "valign": "vcenter",
            "bold": True,
            "font_color": "#FFFFFF",
        }
    )
    font_dark_format = workbook.add_format(
        {
            "border": 1,
            "align": "center",
            "valign": "vcenter",
            "bold": True,
            "font_color": "#000000",
        }
    )
    hidden_value_format = workbook.add_format(
        {"border": 1, "align": "center", "valign": "vcenter", "num_format": ";;;"},
    )

    # --- Подготовка данных и расчет макс. ранга ---
    rank_columns = df.columns[4:]
    if len(rank_columns) >= 2:
        step = int(str(rank_columns[1])) - int(str(rank_columns[0]))
    else:
        step = 1
    mid = step / 2
    numeric_data = df[rank_columns].apply(pd.to_numeric, errors="coerce")
    if max_rank is None:
        finite_values = numeric_data.to_numpy(dtype=float)
        finite_values = finite_values[np.isfinite(finite_values)]
        if finite_values.size == 0:
            raise ValueError("Input table contains no numeric values")
        max_rank = int(finite_values.max())
    else:
        finite_values = numeric_data.to_numpy(dtype=float)
        finite_values = finite_values[np.isfinite(finite_values)]
        if finite_values.size == 0:
            raise ValueError("Input table contains no numeric values")

    # if display_mode == "ratio":
    #     color_scale_rule = {
    #         "type": "3_color_scale",
    #         "min_value": 0.0,
    #         "min_type": "num",
    #         "min_color": "#FFFFFF",
    #         "mid_value": 0.5,
    #         "mid_type": "num",
    #         "mid_color": "#FE7E00",
    #         "max_value": 1.0,
    #         "max_type": "num",
    #         "max_color": "#000000",
    #     }
    #     legend_ticks = np.round(np.arange(0.0, 1.0 + 0.1, 0.1), 1)
    #     value_label = "Ratio"
    #
    font_light_rule = {
        "type": "cell",
        "criteria": "greater than",
        "value": 0.5,
        "format": heatmap_text_format,
    }
    font_dark_rule = {
        "type": "cell",
        "criteria": "less than or equal",
        "value": 0.5,
        "format": font_dark_format,
    }

    if display_mode == "ratio":
        base_cmap = plt.get_cmap("afmhot_r")

        cmap_min = 0.0
        cmap_max = 0.9

        min_color = mcolors.to_hex(base_cmap(cmap_min))
        mid_color = mcolors.to_hex(base_cmap((cmap_min + cmap_max) / 2))
        max_color = mcolors.to_hex(base_cmap(cmap_max))

        color_scale_rule = {
            "type": "3_color_scale",

            # диапазон ЗНАЧЕНИЙ остаётся 0..1
            "min_value": 0.0,
            "min_type": "num",
            "min_color": min_color,

            "mid_value": 0.5,
            "mid_type": "num",
            "mid_color": mid_color,

            "max_value": 1.0,
            "max_type": "num",
            "max_color": max_color,
        }

        legend_ticks = np.round(np.arange(0.0, 1.0 + 0.1, 0.1), 1)
        value_label = "Ratio"
    else:
        color_scale_rule = {
            "type": "3_color_scale",
            "min_value": 1 - mid,
            "min_type": "num",
            "min_color": "#FF0000",
            "mid_value": 1 + (max_rank - 1) / 2,
            "mid_type": "num",
            "mid_color": "#32AD2D",
            "max_value": max_rank + mid,
            "max_type": "num",
            "max_color": "#0004FF",
        }
        legend_ticks = list(range(1, max_rank + 1, step))
        value_label = "Rank"

    # --- Заголовки ---
    for col_num, value in enumerate(df.columns.values):
        worksheet.write(0, col_num, value, header_format)

    # --- Тело таблицы ---
    for row_num, (_, row) in enumerate(df.iterrows(), start=1):
        for col_idx, value in enumerate(row):
            if col_idx == 3:
                worksheet.write_blank(row_num, col_idx, None, cell_format)
            else:
                if pd.isna(value):
                    worksheet.write_blank(row_num, col_idx, None, cell_format)
                else:
                    if hide_values and col_idx >= 4:
                        worksheet.write(row_num, col_idx, value, hidden_value_format)
                    else:
                        if (
                            display_mode == "ratio"
                            and col_idx >= 4
                            and isinstance(value, (int, float))
                        ):
                            value = round(float(value), 2)
                        worksheet.write(row_num, col_idx, value, cell_format)

    render_dpi = max(1, logo_dpi)
    logo_height_px = max(1, int(round(logo_height * render_dpi)))
    row_height_points = logo_height * 72.0
    row_height_px = max(1, int(round(logo_height * 96.0)))

    # --- Подготовка PNG логотипов (кэш + multiprocessing для cache miss) ---
    motif_ids = [str(m).strip() for m in df["Motif"]]
    render_params = LogoRenderParams(
        logo_height_px=logo_height_px,
        base_width_per_nt=base_width_per_nt,
        font_name="sans-serif",
    )

    logo_map, render_errors = collect_logo_pngs(
        motif_ids=motif_ids,
        db_mode=db_mode,
        hocomoco_path=hocomoco_path,
        extra_motifs_path=extra_motifs_path,
        render_params=render_params,
        jobs=jobs,
        cache_dir=cache_dir,
        no_cache=no_cache,
    )

    for motif_id, error_text in render_errors.items():
        print(
            f"Warning: Could not render motif logo {motif_id}: {error_text}",
            file=sys.stderr,
        )

    max_nt = max((motif_len for _, motif_len in logo_map.values()), default=0)

    # --- Настройка ширин колонок ---
    worksheet.set_column(0, 0, 32)
    worksheet.set_column(1, 1, 16)
    worksheet.set_column(2, 2, 24)
    logo_col_width, logo_col_width_px = logo_column_width(
        motif_length_nt=max_nt,
        base_width_per_nt=base_width_per_nt,
        logo_dpi=render_params.logo_dpi,
    )
    worksheet.set_column(3, 3, logo_col_width)
    if len(df.columns) > 4:
        worksheet.set_column(4, len(df.columns) - 1, 6)

    # --- Установка высоты строк ---
    for row_num in range(1, len(df) + 1):
        worksheet.set_row(row_num, row_height_points)

    # --- Условное форматирование ---
    font_rules = None
    if display_mode == "ratio":
        font_rules = [font_dark_rule, font_light_rule]
    elif not hide_values:
        font_rules = [{"type": "no_blanks", "format": heatmap_text_format}]

    if len(df.columns) > 4:
        worksheet.conditional_format(
            1, 4, len(df), len(df.columns) - 1, color_scale_rule
        )
        for rule in font_rules:
            worksheet.conditional_format(
                1, 4, len(df), len(df.columns) - 1, rule
            )

    # --- Легенда (ограниченная по высоте) ---
    legend_col_idx = len(df.columns) + 2
    worksheet.set_column(legend_col_idx, legend_col_idx, 8)
    worksheet.write(0, legend_col_idx, value_label, header_format)
    for i, r in enumerate(legend_ticks, start=1):
        if display_mode == "ratio":
            r = round(float(r), 2)
        worksheet.write(i, legend_col_idx, r, cell_format)

    worksheet.conditional_format(
        1, legend_col_idx, len(legend_ticks), legend_col_idx, color_scale_rule
    )

    for rule in font_rules:
        worksheet.conditional_format(
            1,
            legend_col_idx,
            len(legend_ticks),
            legend_col_idx,
            rule,
        )

    # --- Вставка логотипов ---
    for i, motif_id in enumerate(motif_ids):
        logo_item = logo_map.get(motif_id)
        if logo_item is None:
            continue
        png_bytes, _ = logo_item
        img_buffer = io.BytesIO(png_bytes)
        img_buffer.seek(0)

        png_width_px, png_height_px = png_dimensions(png_bytes)

        max_width_px = max(1, logo_col_width_px - 8)
        max_height_px = max(1, row_height_px - 4)
        scale = min(1.0, max_width_px / png_width_px, max_height_px / png_height_px)
        dpi_scale = render_params.logo_dpi / 96.0
        xlsx_scale = scale * dpi_scale

        draw_width_px = int(png_width_px * scale)
        draw_height_px = int(png_height_px * scale)
        x_offset = max(0, (logo_col_width_px - draw_width_px) // 2)
        y_offset = max(0, (row_height_px - draw_height_px) // 2)

        worksheet.insert_image(
            i + 1,
            3,
            f"logo_{i}.png",
            {
                "image_data": img_buffer,
                "x_offset": x_offset,
                "y_offset": y_offset,
                "x_scale": xlsx_scale,
                "y_scale": xlsx_scale,
                "object_position": 1,
            },
        )

    writer.close()
    print(f"Success: table saved to {output_path}")


def add_xlsx_subparser(subparsers: argparse._SubParsersAction):
    default_hocomoco = default_hocomoco_path()
    parser = subparsers.add_parser("xlsx", help="Export motifs into Excel workbook")
    parser.add_argument(
        "-i",
        "--input",
        required=True,
        help="Path to input TSV table (path/to/data.tsv)",
    )
    parser.add_argument(
        "-o",
        "--output",
        required=True,
        help="Path to XLSX table (e.g. your/path/to/write/file.xlsx)",
    )
    parser.add_argument(
        "--db",
        choices=["jaspar", "hocomoco"],
        required=True,
        help="Motif database to use",
    )
    mode_group = parser.add_mutually_exclusive_group(required=True)
    mode_group.add_argument(
        "--rank",
        dest="display_mode",
        action="store_const",
        const="rank",
        help="Render values with the rank color scale",
    )
    mode_group.add_argument(
        "--ratio",
        dest="display_mode",
        action="store_const",
        const="ratio",
        help="Render values with a grayscale ratio scale",
    )
    parser.add_argument(
        "--hocomoco-path",
        default=default_hocomoco,
        help=f"Path to HOCOMOCO data (default: {default_hocomoco})",
    )
    parser.add_argument(
        "--max-rank",
        type=int,
        help="Maximum rank for --rank color scaling (calculated if not provided)",
    )
    parser.add_argument(
        "--hide-values",
        action="store_true",
        help="Hide numeric values in the heatmap area (colors only)",
    )
    parser.add_argument(
        "-j",
        "--jobs",
        type=int,
        default=1,
        help="Number of worker processes for uncached logo rendering (default: %(default)s)",
    )
    parser.add_argument("--cache-dir", help="Path to PNG logo cache directory")
    parser.add_argument(
        "--no-cache",
        action="store_true",
        help="Disable PNG logo cache",
    )
    parser.add_argument(
        "--logo-height",
        type=float,
        default=0.3,
        help="Base logo height in inches (default: %(default)s)",
    )
    parser.add_argument(
        "--base-width-per-nt",
        type=float,
        default=0.15,
        help="Base logo width per nucleotide for rendering (default: %(default)s)",
    )
    parser.add_argument(
        "--logo-dpi",
        type=int,
        default=300,
        help="DPI used for logo rendering (default: %(default)s)",
    )
    parser.add_argument(
        "--extra-motifs-path",
        help="Path to fallback motifs file in FASTA-like PFM format",
    )
    parser.set_defaults(handler=run_xlsx_command)


def run_xlsx_command(args: argparse.Namespace):
    if args.db == "hocomoco" and not args.hocomoco_path:
        raise ValueError("--hocomoco-path is required when --db is hocomoco")
    if args.display_mode == "ratio" and args.max_rank is not None:
        raise ValueError("--max-rank can only be used with --rank")

    generate_excel_with_logos(
        args.input,
        args.output,
        args.db,
        args.hocomoco_path,
        max_rank=args.max_rank,
        hide_values=args.hide_values,
        jobs=max(1, args.jobs),
        cache_dir=args.cache_dir,
        no_cache=args.no_cache,
        logo_height=args.logo_height,
        base_width_per_nt=args.base_width_per_nt,
        logo_dpi=args.logo_dpi,
        extra_motifs_path=args.extra_motifs_path,
        display_mode=args.display_mode,
    )
