import importlib.resources
import sys


def default_hocomoco_path() -> str | None:
    try:
        ref = (
            importlib.resources.files("gromosega_tools")
            / "data"
            / "H14CORE_annotation.zip"
        )
        with importlib.resources.as_file(ref) as p:
            return str(p)
    except Exception as e:
        print(f"Warning: Could not load bundled HOCOMOCO data: {e}", file=sys.stderr)
        return None
