import hashlib
import json
import os
import tempfile
from pathlib import Path


CACHE_VERSION = "v1"


def default_cache_dir() -> Path:
    base_dir = Path(os.environ.get("XDG_CACHE_HOME", Path.home() / ".cache"))
    return base_dir / "gromosega-tools" / "logo_png" / CACHE_VERSION


def build_db_fingerprint(
    db_mode: str,
    jaspar_release: str = "JASPAR2026",
    hocomoco_path: str | None = None,
    extra_motifs_path: str | None = None,
) -> str:
    def path_fingerprint(path_value: str | None, label: str) -> str:
        if not path_value:
            return f"{label}:missing"
        path = Path(path_value).expanduser().resolve()
        try:
            stat = path.stat()
            return f"{label}:{path}:{stat.st_mtime_ns}:{stat.st_size}"
        except FileNotFoundError:
            return f"{label}:not_found:{path}"

    if db_mode == "jaspar":
        primary = f"jaspar:{jaspar_release}"
        secondary = path_fingerprint(hocomoco_path, "hocomoco")
    elif db_mode == "hocomoco":
        primary = path_fingerprint(hocomoco_path, "hocomoco")
        secondary = f"jaspar:{jaspar_release}"
    else:
        raise ValueError(f"Unknown db mode: {db_mode}")

    extra = path_fingerprint(extra_motifs_path, "extra_motifs")
    return f"primary={primary}|secondary={secondary}|extra={extra}"


class LogoPngCache:
    def __init__(self, cache_dir: str | None = None):
        self.cache_dir = (
            Path(cache_dir).expanduser().resolve() if cache_dir else default_cache_dir()
        )

    def _key_hash(
        self, motif_id: str, db_fingerprint: str, render_params: dict[str, object]
    ) -> str:
        payload = {
            "cache_version": CACHE_VERSION,
            "motif_id": motif_id,
            "db_fingerprint": db_fingerprint,
            "render_params": render_params,
        }
        raw = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
        return hashlib.sha256(raw).hexdigest()

    def _paths(self, key_hash: str) -> tuple[Path, Path]:
        subdir = self.cache_dir / key_hash[:2] / key_hash[2:4]
        png_path = subdir / f"{key_hash}.png"
        meta_path = subdir / f"{key_hash}.json"
        return png_path, meta_path

    def get(
        self,
        motif_id: str,
        db_fingerprint: str,
        render_params: dict[str, object],
    ) -> tuple[bytes, int] | None:
        key_hash = self._key_hash(motif_id, db_fingerprint, render_params)
        png_path, meta_path = self._paths(key_hash)
        if not png_path.exists() or not meta_path.exists():
            return None

        try:
            with meta_path.open("r", encoding="utf-8") as f:
                meta = json.load(f)
            motif_length = int(meta["motif_length"])
            png_bytes = png_path.read_bytes()
            return png_bytes, motif_length
        except Exception:
            return None

    def put(
        self,
        motif_id: str,
        db_fingerprint: str,
        render_params: dict[str, object],
        png_bytes: bytes,
        motif_length: int,
    ) -> None:
        key_hash = self._key_hash(motif_id, db_fingerprint, render_params)
        png_path, meta_path = self._paths(key_hash)
        png_path.parent.mkdir(parents=True, exist_ok=True)

        meta = {
            "cache_version": CACHE_VERSION,
            "motif_id": motif_id,
            "motif_length": int(motif_length),
        }

        with tempfile.NamedTemporaryFile(dir=png_path.parent, delete=False) as tmp_png:
            tmp_png.write(png_bytes)
            tmp_png_path = Path(tmp_png.name)

        with tempfile.NamedTemporaryFile(
            dir=meta_path.parent,
            mode="w",
            encoding="utf-8",
            delete=False,
        ) as tmp_meta:
            json.dump(meta, tmp_meta, separators=(",", ":"), ensure_ascii=True)
            tmp_meta_path = Path(tmp_meta.name)

        os.replace(tmp_png_path, png_path)
        os.replace(tmp_meta_path, meta_path)
