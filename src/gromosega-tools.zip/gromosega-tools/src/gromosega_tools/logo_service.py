from gromosega_tools.logo_png_cache import LogoPngCache, build_db_fingerprint
from gromosega_tools.logo_workers import LogoRenderParams, render_missing_logos


def collect_logo_pngs(
    motif_ids: list[str],
    db_mode: str,
    hocomoco_path: str | None,
    render_params: LogoRenderParams,
    jobs: int,
    cache_dir: str | None,
    no_cache: bool,
    extra_motifs_path: str | None = None,
    jaspar_release: str = "JASPAR2026",
) -> tuple[dict[str, tuple[bytes, int]], dict[str, str]]:
    unique_motif_ids = list(dict.fromkeys(motif_ids))
    logo_map: dict[str, tuple[bytes, int]] = {}
    missing_motifs: list[str] = []

    cache = None if no_cache else LogoPngCache(cache_dir=cache_dir)
    db_fingerprint = build_db_fingerprint(
        db_mode=db_mode,
        jaspar_release=jaspar_release,
        hocomoco_path=hocomoco_path,
        extra_motifs_path=extra_motifs_path,
    )
    render_key = render_params.to_key_dict()

    for motif_id in unique_motif_ids:
        if cache is None:
            missing_motifs.append(motif_id)
            continue

        cached = cache.get(motif_id, db_fingerprint, render_key)
        if cached is None:
            missing_motifs.append(motif_id)
        else:
            logo_map[motif_id] = cached

    rendered_map, render_errors = render_missing_logos(
        motif_ids=missing_motifs,
        db_mode=db_mode,
        hocomoco_path=hocomoco_path,
        extra_motifs_path=extra_motifs_path,
        jaspar_release=jaspar_release,
        render_params=render_params,
        jobs=jobs,
        strict=False,
    )

    for motif_id, value in rendered_map.items():
        logo_map[motif_id] = value
        if cache is None:
            continue
        png_bytes, motif_len = value
        cache.put(
            motif_id,
            db_fingerprint,
            render_key,
            png_bytes,
            motif_len,
        )

    return logo_map, render_errors
