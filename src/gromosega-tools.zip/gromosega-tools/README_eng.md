# Gromosega Tools

Gromosega results visualization toolkit.

## Tools
- 'gromosega-tools heatmap': Creating heat maps.
- 'gromosega-tools xlsx': Export data to Excel with generation of logo motives.

## Installation

To install, you need the package manager [uv](https://github.com/astral-sh/uv), it will install the package and all the necessary dependencies.

```bash
cd ./gromosega-tools
uv tool install . # or uv tool install . --reinstall to reinstall the current version
```

After installation, the 'gromosega-tools' command will be available, which is automatically added to the PATH.

## Start examples

Examples of input data and ready-made scripts are in the directory 'examples/'.

### Automatic start

You can run all examples with one command using the prepared script:

```bash
bash examples/example_run.sh
```

### Manual start and parameters

Below are examples of launching with a description of the main parameters, to launch them you need to be in the directory 'examples', or you need to write the full path to the input and output data.

**1. JASPAR * * Heatmap

```bash
gromosega-tools heatmap -i ./auxin/rank_mot_do_05h_0.8 \
                        -o ./plots/rank_mot_do_05h_0.8.png \
                        --db jaspar \
                        --rank
```
* '-i' is the path to the input file (TSV table).
* '-o' is the path to save the result (image). The picture is recorded in the format specified in the file extension.
* '--db' - selection of the motive database ('jaspar' or 'hocomoco').
* '--rank' - heatmap of ranks (integer values).
* '--ratio' - heatmap of ratios (float values).

Exactly one of the '--rank' and '--ratio' flags must be specified.

**2. Excel spreadsheet (JASPAR) * *

```bash
gromosega-tools xlsx -i ./auxin/rank_mot_do_05h_0.8 \
                     -o ./tables/rank_mot_do_05h_0.8.xlsx \
                     --db jaspar \
                     --rank
```

**3. Excel spreadsheet (HOCOMOCO) * *

```bash
gromosega-tools xlsx -i ./fox/rank_mot_up_foxta5 \
                     -o ./tables/rank_mot_up_foxta5.8.xlsx \
                     --db hocomoco \
                     --rank
```

## Description of operation and parameters

A PNG motif logo cache has been added to the project.

- For 'gromosega-tools xlsx', the cache is always used (logos are inserted as PNG).
- For 'gromosega-tools heatmap', the cache is used only when the output format is' .png '.
- For vector outputs ('.pdf', '.svg') in 'gromosega-tools heatmap', normal rendering through 'logomaker' is used.

Main parameters:

- '-j, --jobs' - the number of processes for generating new (not cached) logos.
- '--cache-dir' - path to the PNG cache directory.
- '--no-cache' - disable cache.
- '--base-width-per-nt' and '--logo-height' are the basic size parameters from which other dimensions are automatically calculated (including the width of the logo area in 'xlsx' and 'heatmap'); '--logo-height' is set in inches.
- '--logo-dpi' - DPI for the logo render (default '300').
- '--extra-motifs-path' - path to the additional motive file (FASTA-like PFM), which is used by the latter in the chain of searching for motives.

When searching for a motive, the following chain is used:
1. first selected through '--db' base.
2. then an alternative base ('jaspar' <-> 'hocomoco').
3. last file from '--extra-motifs-path'.

If '--cache-dir' is not specified, the default directory is used:

`~/.cache/gromosega-tools/logo_png/v1`