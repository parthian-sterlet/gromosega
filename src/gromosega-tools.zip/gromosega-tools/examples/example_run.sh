#!/bin/bash

echo rank_mot_up_foxta5
gromosega-tools xlsx -i ./fox/rank_mot_up_foxta5 -o ./tables/rank_mot_up_foxta5.8.xlsx --db hocomoco --rank
gromosega-tools heatmap -i ./fox/rank_mot_up_foxta5 -o ./plots/rank_mot_up_foxta5.8.png --db hocomoco --rank

echo rank_mot_do_HP_ML_70
gromosega-tools xlsx -i ./step/rank_mot_do_HP_ML_70 -o ./tables/rank_mot_do_HP_ML_70.xlsx --db hocomoco --rank
gromosega-tools heatmap -i ./step/rank_mot_do_HP_ML_70 -o ./plots/rank_mot_do_HP_ML_70.png --db hocomoco --rank

echo rank_mot_up_auxin_30min_2_90
gromosega-tools xlsx -i ./rank_mot_up_auxin_30min_2_90 -o ./tables/rank_mot_up_auxin_30min_2_90.xlsx --db jaspar --rank
gromosega-tools heatmap -i ./rank_mot_up_auxin_30min_2_90 -o ./plots/rank_mot_up_auxin_30min_2_90.png --db jaspar --rank

echo ratio_mot_up_auxin_30min_2_90
gromosega-tools xlsx -i ./ratio_mot_up_auxin_30min_2_90 -o ./tables/ratio_mot_up_auxin_30min_2_90.xlsx --db jaspar --ratio
gromosega-tools heatmap -i ./ratio_mot_up_auxin_30min_2_90 -o ./plots/ratio_mot_up_auxin_30min_2_90.png --db jaspar --ratio


for file in ./auxin/*
do
    name=$(basename $file)
    echo $name

    gromosega-tools heatmap -i ./auxin/${name} -o ./plots/${name}.png --db jaspar --rank
    gromosega-tools xlsx -i ./auxin/${name} -o ./tables/${name}.xlsx --db jaspar --rank
done
